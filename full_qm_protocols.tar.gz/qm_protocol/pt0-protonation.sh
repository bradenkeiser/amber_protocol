#!bin/bash
echo "this takes a relaxed PDB file and properly protonates it for Amber"
echo "This does NOT change any residue names from what is protonated by pdb2pqr"
echo "Example:"
echo "bash pt0-protonation.sh WT_protonated"

model=$1 # name of PDB file WITHOUT '.pdb'

awk '$1=="ATOM" || $1=="TER" || $1=="END"' ${model}.pdb > ${model}_clean.pdb

pdb2pqr30 --ff=AMBER --ffout=AMBER --keep-chain --titration-state-method propka --with-ph 6.5 --pdb-output=pre.pdb ${model}_clean.pdb ${model}_clean.pqr

cp pre.pdb ${model}_protonated.pdb


