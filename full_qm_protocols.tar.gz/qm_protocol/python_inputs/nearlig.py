# -*- coding: utf-8 -*-
"""
Created on Tue May 16 11:48:31 2023

@author: Braden
"""

import MDAnalysis as mda
import numpy 
import os, sys, glob
import pandas as pd
print('this requires: $(pwd) name/test tpr trj')
os.chdir(sys.argv[1])
title=sys.argv[2]
broken=str.split(title, sep = '/')
name = broken[0]; test = broken[1]
tpr=sys.argv[3] # tested with pdb, will try with prmtop
trj=sys.argv[4] # mdcrd
u=mda.Universe(tpr,trj)
traj = u.trajectory
lig = u.select_atoms('resname LIG')
group=[]
frames = []
data = pd.DataFrame(columns=['resid'])
for i, frame_open in enumerate(traj):
    frames.append(i)
    around = u.select_atoms('around 6 resname LIG')
    residues=[]
    for x in around:
        if x.resid in residues:
           # print('residue present, skipping')
           original=x.resid
        else:
            residues.append(x.resid)
    #residues = np.unique(residues)
    residues=pd.Series(residues)
    group.append(residues)
 
    #print_res="17-20;52-56;83-85;115-117;137-138;143-145;160-167; 170-180;203"

data['resid'] = pd.concat(group)
data_mid = data.resid.unique()
data_out = pd.DataFrame(data_mid, columns = ['resid'])
data_out = data_out.sort_values(by='resid', ascending = True)
data_out['resname'] = data_out['resid'].apply(lambda x: u.residues.resnames[x-1])
print('these are the residues nearby with the resnames: ')
print(data_out)

#numbers  = ''
#for x in data_out['resid']:
#    new = str(x)+';'
#    numbers+=new

# Convert the numbers to integers
numbers = list(data_out['resid'])
print(numbers)
ranges = []
start = numbers[0]
end = start
used=[]
# Find consecutive ranges
for i in range(1, len(numbers)):
    if numbers[i] in used:
        print(f'number: {numbers[i]} has been used')
    else:
        if numbers[i] == end + 1:
            end = numbers[i]
            used.append(numbers[i])
        else:
            ranges.append((start, end))
            start = numbers[i]
            end = start

ranges.append((start, end))

# Generate the output string
output_string = ""
for rng in ranges:
    if rng[0] == rng[1]:
        output_string += f"{rng[0]};"
    else:
        output_string += f"{rng[0]}-{rng[1]};"

# Remove the trailing semicolon
output_string = output_string.rstrip(";")

print(output_string)

full_line = '# ' + output_string
decomp_line = pd.DataFrame([full_line])
decomp_line.to_csv(name + '_' + test + '_nearbylig.txt', header = False, index = False)
data_out.to_csv(name + '_' + test + '_nearbylig.txt', header = True, 
                index = None, sep = '\t', mode = 'a')

