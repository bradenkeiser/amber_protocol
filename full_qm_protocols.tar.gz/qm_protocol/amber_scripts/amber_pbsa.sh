#!bin/bash
echo "for running pbsa"
if [[ $# < 4 ]]; then
    echo "this requires at least four inputs: [test_num],[variant_name] [LIG_name], and [mpi_num]"
#run=${1%/*}; test=${1##*/} # e.g. R166C-A197C/2
else
    echo "running $2 test num $1 using the $3 ligand and MPI threads of $4 "
fi
test_num=$1
variant=$2
lig=$3
mpi=$4
echo "running with $mpi processors"
if [[ -z $3 ]]; then
    echo "ante-mmpbsa assumes LIG ligand"
    ante-MMPBSA.py -p protlig-solv.prmtop -c complex.prmtop -r receptor.prmtop -l ligand.prmtop -s ':WAT,:Cl-,:Na+'  -n ':LIG'
else
    ante-MMPBSA.py -p protlig-solv.prmtop -c complex.prmtop -r receptor.prmtop -l ligand.prmtop -s ':WAT,:Cl-,:Na+'  -n ":$lig"
fi
#source /userhome/braden/bashrc x

py='/tarafs/data/home/bkeiser/miniconda3/envs/bifrost/bin/python'

sed -i "s/LIG/$lig/g" nearlig.py
$py nearlig.py $(pwd) $variant/$test_num complex.prmtop complex_nosolv.mdcrd # don't need conda if link python

decomp_pre=$(grep '# ' ${variant}_${test_num}_nearbylig.txt | awk '{print $2}')
decomp="${decomp_pre};786"
echo "this is the grepped decomp terms: $decomp"
sed -i "s#DECOMP_NUM#$decomp#g" mmpbsa.in
grep "print_res" mmpbsa.in
if [[ -z $3 ]]; then
    echo "assuming ligand is LIG"
    if $(grep -q ":MOL" mmpbsa.in ); then
        echo "ligand was MOL"
        sed -i "s/MOL/LIG/g" mmpbsa.in
    else
        echo "kept mmpbsa normal: $(grep "ligand_mask" mmpbsa.in)"
    fi
else
    echo "changing ligand receptor mask to: $lig"
    if $(grep -q ":MOL" mmpbsa.in ); then
        echo "ligand was MOL"
        sed -i "s/MOL/$lig/g" mmpbsa.in
    else
        sed -i "s/LIG/$lig/g" mmpbsa.in
    fi
    grep "ligand_mask" mmpbsa.in
    grep "receptor_mask" mmpbsa.in
fi

frames=$(cpptraj -p complex.prmtop -y complex_nosolv.mdcrd -tl | cut -d: -f2 )
current_frame=$(grep "endframe" mmpbsa.in | awk '{print $1}')
echo "changing frames from $current_frame to $frames"
sed -i "s/$current_frame/endframe=$frames,/g" mmpbsa.in
amber_prog="mpirun -np $mpi"
$amber_prog MMPBSA.py.MPI -O -i mmpbsa.in -o FINAL_RESULTS_MMPBSA.dat -do FINAL_DECOMP_RESULTS.dat -deo decomp_perframe.csv -sp complex.prmtop -cp complex.prmtop -rp receptor.prmtop -lp ligand.prmtop -y complex_nosolv.mdcrd

