#!/bin/bash

if [[ $# < 2 ]]; then
    echo "this scripts makes directories for your proteins"
    echo "Required: [protein pdb] and [directory_name]"
    exit 1
else
    echo "making directories for $1 in $2"
fi

protein=$1
dir=$2
base=$(pwd)
protocol=${pwd}/..

mkdir $dir
cp $protein $dir/./
cp $protocol/run*slurm $dir/./
cp $protocol/pt1*2024.sh $dir/./
cp $protocol/amber_scripts/ligand_analysis.sh $dir/./
cp $protocol/amber_scripts/get_results.sh $dir/./
cp $protocol/*pt5* $dir/./

echo "made directory: $dir"
echo "these are the contents: $(dir $dir)"
