#!/bin/bash/

test=$(pwd)
echo $test
