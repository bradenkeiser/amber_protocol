#!/bin/bash

RUNDIR=$(pwd)

protocol=/home/deck/xylanase/finding_ES_model/qm_protocol

bash $protocol/pt2_water_min.sh ${RUNDIR}
